from flask import Flask, request, jsonify, render_template, Response
import os
import json
from datetime import datetime
from datetime import datetime, timedelta

app = Flask(__name__)



@app.route('/')
def render_main_page():  
    return render_template("main_page.html")

def find_nearest_hours(timestamp):
    # 將字符串格式的timestamp轉換為datetime對象
    specified_time = datetime.strptime(timestamp, '%Y-%m-%dT%H:%M:%S.%fZ')
    
    if specified_time.minute == 0:
        previous_hour = specified_time - timedelta(hours=1)
        next_hour = specified_time
    else:
        previous_hour = specified_time.replace(minute=0, second=0, microsecond=0)
        next_hour = previous_hour + timedelta(hours=1)
    
    return previous_hour, next_hour

def save_data_to_json(filepath, data):
    with open(filepath, 'w') as f:
        json.dump(data, f)

def update_glucose_data(json_file, previous_hour, next_hour, new_data):
    try:
        with open(json_file, 'r') as f:
            data = json.load(f)
    except FileNotFoundError:
        data = []
    
    updated = False
    for item in data:
        item_time = datetime.strptime(item['timestamp'], '%Y-%m-%dT%H:%M:%S.%fZ')
        if previous_hour <= item_time < next_hour:
            item.update(new_data)
            updated = True
    
    if not updated:
        data.append(new_data)
    
    save_data_to_json(json_file, data)

@app.route('/submit', methods=['POST'])
def submit_glucose():
    data = request.json
    timestamp = data['timestamp']

    previous_hour, next_hour = find_nearest_hours(timestamp)

    update_glucose_data('json/blood_sugar.json', previous_hour, next_hour, data)

    return jsonify({"status": "success", "message": "血糖值接收成功"})

@app.route("/view-plot")
def render_plot():
    return render_template("plot.html")

@app.route('/get-data', methods=['GET'])
def get_data():
    # 假設您的JSON數據存儲在data.json文件中
    with open('json/blood_sugar.json', 'r') as file:
        data = json.load(file)
    return jsonify(data)

if __name__ == '__main__':
    app.run(debug=True)
