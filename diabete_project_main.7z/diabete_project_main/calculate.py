def calculate_insulin_dose(weight, carb_intake, current_blood_sugar, target_blood_sugar, insulin_sensitivity=30, carb_response=30):
    """
    根據提供的個人數據和假設參數計算所需的胰島素單位。

    參數:
    weight (float): 體重（公斤）。
    carb_intake (int): 餐前碳水化合物攝取量（以15公克碳水化合物為一份）。
    current_blood_sugar (int): 當前血糖值（mg/dL）。
    target_blood_sugar (int): 目標血糖值（mg/dL）。
    insulin_sensitivity (int): 每單位胰島素對血糖下降的影響（mg/dL），預設為30。
    carb_response (int): 每份碳水化合物（15公克）對血糖上升的影響（mg/dL），預設為30。

    返回:
    float: 餐前應注射的胰島素單位。
    """
    # 計算每天所需胰島素總量（假設使用體重*0.5）
    total_daily_insulin = weight * 0.5
    
    # 計算基礎胰島素（假設為總量的50%）
    basal_insulin = total_daily_insulin * 0.5
    
    # 計算餐前需要的額外胰島素量
    # 碳水化合物攝取對血糖的影響
    carb_impact = carb_intake * carb_response
    # 目標血糖調整所需的胰島素
    adjustment_insulin = (carb_impact + target_blood_sugar - current_blood_sugar) / insulin_sensitivity
    
    # 總計需要的額外胰島素量（若計算結果為負，則不需額外胰島素）
    total_mealtime_insulin = max(adjustment_insulin, 0)
    
    return total_mealtime_insulin

